
Pre-Requirement:
1) PHP website setup 
2) The code uses PDO extension and PDO SQLITE driver to connect to SQLite
  database, both should be enabled by default as of PHP 5.1.0.


PHP Specification Section

1) This code contains PHP 5.6.25 ,HTML5,CSS,bootstrap,Javascript and SQLite Database and Members table to Register New User.

2) The New Member/User Page sign's up using user name, gender and password and validate for username & password length and make selecting gender mandatory
--- Note The scope of current client validation allows to accept minimum user name and password of 8 characters and cannot be blank

3) The successfully created user is allowed to enter the membership page area(currently blank)

4) The data inserted is stored and validated using members table.

5) The password is encrypted using php hash algorithm http://php.net/manual/en/function.password-hash.php and stored in database  

