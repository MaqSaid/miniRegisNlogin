<?php
ob_start();
session_start();

//set timezone
date_default_timezone_set('australia/melbourne');

try {

	//create PDO connection for SQLITE in root folder.
	$db = new PDO('sqlite:UserInfo.sq3');
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch(PDOException $e) {
	//show error
    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
    exit;
}

//include the user class instance , pass in the database object connection
include('classes/user.php');
$user = new User($db);
?>
