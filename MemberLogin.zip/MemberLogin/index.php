<?php require('includes/config.php');

// This is root page the website loads by default and has link to login page

//if logged in redirect to members page
if( $user->is_logged_in() ){ header('Location: memberpage.php'); } // Returns true or false

//if form has been submitted process it
if(isset($_POST['submit'])){

	// basic validation, we can add more for to accept more than 8 characters for username
	if(strlen($_POST['username']) < 8){
		$error[] = 'Username should be atleast 8 characters long';
	} else {
		$stmt = $db->prepare('SELECT username FROM members WHERE username = :username');
		$stmt->execute(array(':username' => $_POST['username']));
		$row = $stmt->fetch(PDO::FETCH_ASSOC);

		if(!empty($row['username'])){
			$error[] = 'Username provided is already in use.';
		}

	}

	 // Currently accepts minumum 8 charter user name and password
	 // Note but can be further scoped to accept more than 8 characters and combination of alphabets, numbers and special characters
	if(strlen($_POST['password']) < 8){
		$error[] = 'Password should be atleast 8 characters long';
	}

	if(strlen($_POST['passwordConfirm']) < 8){
		$error[] = 'Confirm password is too short.';
	}
    
	if(isset($_POST['gender']) && $_POST['gender'] == '0') { 
       $error[] = 'Please select gender'; 
	   // echo $_POST['gender'];
      } 
	if($_POST['password'] != $_POST['passwordConfirm']){
		$error[] = 'Password and Confirm Password do not match.';
	}

	
	//if no errors have been created carry on
	if(!isset($error)){

		//hash the password. Encrpyted using http://php.net/manual/en/function.password-hash.php
		$hashedpassword = $user->password_hash($_POST['password'], PASSWORD_BCRYPT);


		try {

			//insert into members table with a prepared sqlite statement
			$stmt = $db->prepare('INSERT INTO members (username,gender,password) VALUES (:username,:gender,:password)');
			$stmt->execute(array(
				':username' => $_POST['username'],
				':gender' => $_POST['gender'],
				':password' => $hashedpassword				
			));
			$id = $db->lastInsertId('memberID');

			//redirect to index/home page
			header('Location: index.php?action=joined');
			exit;

		//else catch the exception and show the error.
		} catch(PDOException $e) {
		    $error[] = $e->getMessage();
		}

	}

}

//define page title
$title = 'Mental Health First Aid Australia';

//include header template
require('layout/header.php');
?>


<div class="container">

	<div class="row">

	    <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
			<form role="form" method="post" action="" autocomplete="off">
				<h2>Please Sign Up</h2>
				<p>Already a Registed Member of MHFAA? <a href='login.php'>Login</a></p>
				<hr>

				<?php
				//check for any errors
				if(isset($error)){
					foreach($error as $error){
						echo '<p class="bg-danger">'.$error.'</p>';
					}
				}

				//if action is joined show success message
				if(isset($_GET['action']) && $_GET['action'] == 'joined'){
					echo "<h2 class='bg-success'>Registration successful, please click on above link of Login</h2>";
				}
				?>

				<div class="form-group">
					<input type="text" name="username" id="username" class="form-control input-lg" placeholder="User Name" value="<?php if(isset($error)){ echo $_POST['username']; } ?>" tabindex="1">
				</div>
				<div class="form-group">
					<select id="gender" name="gender" class="form-control input-lg" tabindex="2">
					   <option value="0">-- Select Gender --</option>
					   <option value="M"> Male </option>
					   <option value="F"> Female </option>
					   <option value="O"> Other </option>	
                    </select>
				</div>
				<div class="row">
					<div class="col-xs-6 col-sm-6 col-md-6">
						<div class="form-group">
							<input type="password" name="password" id="password" class="form-control input-lg" placeholder="Password" tabindex="3">
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6">
						<div class="form-group">
							<input type="password" name="passwordConfirm" id="passwordConfirm" class="form-control input-lg" placeholder="Confirm Password" tabindex="4">
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-xs-6 col-md-6"><input type="submit" name="submit" value="Register" class="btn btn-success btn-block btn-lg" tabindex="5"></div>
				</div>
			</form>
		</div>
	</div>

</div>

<?php
//include footer template to be repeated in every page
require('layout/footer.php');
?>
